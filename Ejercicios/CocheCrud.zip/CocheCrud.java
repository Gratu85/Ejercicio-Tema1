package EjercicioTema5;


import java.util.List;

public interface CocheCrud {

    public void save ();
    public void delete();
    public List findall();




}
